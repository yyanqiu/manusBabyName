# -*- coding: utf-8 -*-
"""
取名生成器主程序
根据姓氏、性别、出生日期生成推荐名字
"""

import datetime
from wuge_calculator import WuGeCalculator
from sancai_analyzer import SanCaiAnalyzer
from data_81_numbers import get_number_luck, get_number_meaning
from data_characters import get_characters_by_stroke_and_gender, get_character_info, CHARACTERS


class NamingGenerator:
    """取名生成器"""
    
    def __init__(self, surname, gender, birthdate=None):
        """
        初始化
        :param surname: 姓氏
        :param gender: 性别（"男"/"女"）
        :param birthdate: 出生日期（可选，用于八字分析）
        """
        self.surname = surname
        self.gender = gender
        self.birthdate = birthdate
        
        # 获取姓氏笔画
        surname_info = get_character_info(surname[0]) if len(surname) > 0 else None
        self.surname_stroke = surname_info["笔画"] if surname_info else None
        
    def generate_names(self, count=20):
        """
        生成推荐名字列表
        :param count: 生成数量
        :return: 名字列表（已评分排序）
        """
        candidates = []
        
        # 遍历所有可能的双名组合
        for char1 in CHARACTERS.keys():
            char1_info = CHARACTERS[char1]
            
            # 检查第一个字是否适合该性别
            if self.gender not in char1_info["性别"]:
                continue
            
            # 常用度筛选（至少3分）
            if char1_info["常用度"] < 3:
                continue
                
            for char2 in CHARACTERS.keys():
                char2_info = CHARACTERS[char2]
                
                # 检查第二个字是否适合该性别
                if self.gender not in char2_info["性别"]:
                    continue
                
                # 常用度筛选
                if char2_info["常用度"] < 3:
                    continue
                
                # 避免重复字
                if char1 == char2:
                    continue
                
                # 生成完整姓名
                full_name = self.surname + char1 + char2
                
                # 计算评分
                score_result = self.evaluate_name(full_name)
                
                # 只保留评分较高的名字（≥70分）
                if score_result["总分"] >= 70:
                    candidates.append({
                        "姓名": full_name,
                        "名字": char1 + char2,
                        "评分": score_result
                    })
        
        # 按总分排序
        candidates.sort(key=lambda x: x["评分"]["总分"], reverse=True)
        
        return candidates[:count]
    
    def evaluate_name(self, full_name):
        """
        评估名字得分
        :param full_name: 完整姓名
        :return: 评分结果字典
        """
        # 提取姓和名
        surname = self.surname
        name = full_name[len(surname):]
        
        # 计算五格
        calc = WuGeCalculator(surname, name)
        wuge_result = calc.calculate_all()
        
        # 计算五格吉凶得分（满分40分）
        wuge_score = 0
        wuge_details = {}
        
        for ge_name, ge_info in wuge_result.items():
            num = ge_info["数值"]
            luck = get_number_luck(num)
            wuge_details[ge_name] = {
                "数值": num,
                "五行": ge_info["五行"],
                "吉凶": luck
            }
            if luck == "吉":
                wuge_score += 8  # 每个格吉，得8分
        
        # 计算三才配置得分（满分30分）
        sancai_result = SanCaiAnalyzer.analyze_sancai(
            wuge_result["天格"]["五行"],
            wuge_result["人格"]["五行"],
            wuge_result["地格"]["五行"]
        )
        sancai_score = sancai_result["得分"]
        
        # 计算字义音韵得分（满分20分）
        ziyi_score = self._evaluate_meaning_and_sound(name)
        
        # 计算八字匹配得分（满分10分，暂时给默认分）
        bazi_score = 5  # 默认5分
        
        # 总分
        total_score = wuge_score + sancai_score + ziyi_score + bazi_score
        
        return {
            "总分": total_score,
            "五格得分": wuge_score,
            "三才得分": sancai_score,
            "字义得分": ziyi_score,
            "八字得分": bazi_score,
            "五格详情": wuge_details,
            "三才详情": sancai_result,
            "三才配置": calc.get_sancai()
        }
    
    def _evaluate_meaning_and_sound(self, name):
        """
        评估字义和音韵
        :param name: 名字（不含姓）
        :return: 得分（0-20）
        """
        score = 0
        
        # 字义评分（根据常用度）
        for char in name:
            char_info = get_character_info(char)
            if char_info:
                score += char_info["常用度"]  # 常用度1-5分
        
        # 音韵评分（简单判断：避免相同声母）
        if len(name) == 2:
            char1_info = get_character_info(name[0])
            char2_info = get_character_info(name[1])
            
            if char1_info and char2_info:
                pinyin1 = char1_info["拼音"]
                pinyin2 = char2_info["拼音"]
                
                # 声母不同，加分
                if pinyin1[0] != pinyin2[0]:
                    score += 5
        
        # 限制最高分为20
        return min(score, 20)
    
    def format_result(self, name_data, rank):
        """
        格式化输出单个名字的详细信息
        :param name_data: 名字数据
        :param rank: 排名
        :return: 格式化字符串
        """
        full_name = name_data["姓名"]
        name_only = name_data["名字"]
        score_data = name_data["评分"]
        
        output = []
        output.append(f"\n{'='*60}")
        output.append(f"推荐名字 {rank}：{full_name}（综合评分：{score_data['总分']}分）")
        output.append(f"{'='*60}")
        
        # 五格分析
        output.append("\n【五格分析】（满分40分，得分：{}分）".format(score_data["五格得分"]))
        wuge_details = score_data["五格详情"]
        for ge_name in ["天格", "人格", "地格", "总格", "外格"]:
            ge_info = wuge_details[ge_name]
            luck_symbol = "✓" if ge_info["吉凶"] == "吉" else "✗"
            output.append(f"  {ge_name}：{ge_info['数值']}（{ge_info['五行']}）- {ge_info['吉凶']} {luck_symbol}")
        
        # 三才配置
        output.append("\n【三才配置】（满分30分，得分：{}分）".format(score_data["三才得分"]))
        sancai_info = score_data["三才详情"]
        output.append(f"  {sancai_info['三才']} - {sancai_info['评价']}")
        output.append(f"  {sancai_info['详情']}")
        
        # 数理详解（只显示人格和总格）
        output.append("\n【数理详解】")
        renge_num = wuge_details["人格"]["数值"]
        zongge_num = wuge_details["总格"]["数值"]
        
        renge_meaning = get_number_meaning(renge_num)
        output.append(f"  人格{renge_num}：{renge_meaning['名称']} - {renge_meaning['含义']}")
        
        zongge_meaning = get_number_meaning(zongge_num)
        output.append(f"  总格{zongge_num}：{zongge_meaning['名称']} - {zongge_meaning['含义']}")
        
        # 字义解析
        output.append("\n【字义解析】（满分20分，得分：{}分）".format(score_data["字义得分"]))
        for char in name_only:
            char_info = get_character_info(char)
            if char_info:
                output.append(f"  {char}：{char_info['字义']}（{char_info['拼音']}）")
        
        return "\n".join(output)


def main():
    """主程序"""
    print("=" * 60)
    print("三才五格智能取名系统")
    print("=" * 60)
    
    # 获取用户输入
    surname = input("\n请输入姓氏：").strip()
    if not surname:
        print("姓氏不能为空！")
        return
    
    gender = input("请输入性别（男/女）：").strip()
    if gender not in ["男", "女"]:
        print("性别输入有误！")
        return
    
    birthdate_str = input("请输入出生日期（YYYY-MM-DD，可选）：").strip()
    birthdate = None
    if birthdate_str:
        try:
            birthdate = datetime.datetime.strptime(birthdate_str, "%Y-%m-%d")
        except:
            print("日期格式有误，将不考虑八字因素")
    
    count = input("请输入生成名字数量（默认10）：").strip()
    count = int(count) if count.isdigit() else 10
    
    # 生成名字
    print(f"\n正在为{surname}姓{gender}宝宝生成名字，请稍候...")
    
    generator = NamingGenerator(surname, gender, birthdate)
    results = generator.generate_names(count)
    
    if not results:
        print("\n抱歉，未能生成符合条件的名字，请尝试调整筛选条件。")
        return
    
    # 输出结果
    print(f"\n共生成 {len(results)} 个推荐名字：\n")
    
    for i, name_data in enumerate(results, 1):
        print(generator.format_result(name_data, i))
    
    # 保存到文件
    save_option = input("\n\n是否保存结果到文件？(y/n): ").strip().lower()
    if save_option == 'y':
        filename = f"取名结果_{surname}{gender}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(f"三才五格智能取名系统\n")
            f.write(f"姓氏：{surname}\n")
            f.write(f"性别：{gender}\n")
            if birthdate:
                f.write(f"出生日期：{birthdate_str}\n")
            f.write(f"生成时间：{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"\n共生成 {len(results)} 个推荐名字：\n")
            
            for i, name_data in enumerate(results, 1):
                f.write(generator.format_result(name_data, i))
                f.write("\n")
        
        print(f"\n结果已保存到文件：{filename}")


if __name__ == "__main__":
    main()
