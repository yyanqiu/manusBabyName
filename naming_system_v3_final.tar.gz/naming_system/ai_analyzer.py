# -*- coding: utf-8 -*-
import os
from openai import OpenAI

class AIAnalyzer:
    """AI 名字寓意分析器"""
    
    def __init__(self):
        # 使用预配置的 OpenAI 客户端
        self.client = OpenAI()
        self.model = "gpt-4.1-mini"

    def analyze_name(self, surname, name, gender):
        """
        使用 AI 分析名字的深度寓意
        :param surname: 姓氏
        :param name: 名字
        :param gender: 性别
        :return: AI 分析结果字符串
        """
        full_name = surname + name
        prompt = f"""
        你是一位精通中国传统文化、诗词和姓名学的专家。
        请为名字“{full_name}”（性别：{gender}）提供深度的文化寓意分析。
        
        要求：
        1. **文化内涵**：分析名字中每个字的文化背景和组合后的意境。
        2. **诗词出处**：如果可能，引用相关的经典诗词。
        3. **性格寓意**：分析这个名字对孩子性格、志向的正面引导。
        4. **整体评价**：总结名字的雅致程度。
        
        请用专业、优美且富有感染力的语言书写，字数在 200 字左右。
        直接输出分析内容，不要包含“好的”、“根据您的要求”等废话。
        """
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "你是一位专业的姓名学和传统文化专家。"},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            return f"AI 分析暂时不可用（错误：{str(e)}）。该名字寓意优美，象征着美好的未来和高尚的品德。"

if __name__ == "__main__":
    # 简单测试
    analyzer = AIAnalyzer()
    print(analyzer.analyze_name("李", "懿浩", "男"))
